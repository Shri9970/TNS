/**
 * 
 */
/**
 * @author Hp
 *
 */
module JN02CoreJava {
}